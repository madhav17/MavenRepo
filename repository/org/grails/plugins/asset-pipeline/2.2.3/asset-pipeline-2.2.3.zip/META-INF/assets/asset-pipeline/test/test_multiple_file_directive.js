//=require asset-pipeline/test/libs/file_a,asset-pipeline/test/libs/subset/subset_a,asset-pipeline/test/libs/file_b

console.log("Initial Testing Stack for dependency load order");
